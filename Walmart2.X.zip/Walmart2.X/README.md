# Walmart2.X
**About the project**: 
Automation framework for ‘UI testing’ of Walmart Grocery online shopping Application.
[URL]: (https://www.walmart.ca/en/grocery/N-117)
Only three functional scenarios have been included as a part of this project. These tests are designed as smoke test

**Technology/Framework Used**: 
Technology Used : Java, TestNG, Selenium, Maven
Framework Used: Page Object Model

**Files in Project**
  -BasePage.java
  -LandingPage.java
  -ProductPage.java
  -AisleTests.java
  -CartTests.java
  -LandingPageTest.java
  -HelperClass.java
  -TestUtil.java
  -Xls_Reader.java
  -TestListeners.java
  -testngSmoke.xml
  -WalmartScenarios.xlsx
  -pom.xml
  
**Features**:
This project has clearly defined page classes and tes classes and also includes desription of the scenarios that are automated above the method calls to explain their purpose. ReportNG has been used for generating clear and presentable reports. For logs, testNG method Reporter logs have been used to generate the logs that explain the behaviour of functions being executed. 
Currently, the project is using xml file for driving the data and running the tests. Additional files to support excel sheet read and write functionality are included in order to support data retrievel from excel sheet.
After the test run, reports are generated under folder: ( Walmart2.X/test-output/html/index.html )


**Test Scenario Description**
The planned test cases are included under the folder: ( Walmart2.X/smokeTestDescription/WalmartScenarios.xlsx)

**Tests**
In order to setup the project:
1)Clone the repository
2)Covert the project to mave project
3)Change the enironment variables to match the system configurations . Environment variables can be edited under xml document with path:
 (Walmart2.X/src/test/java/TestNg/testngsmoke.xml). The environment variables to be edited are:
 browser
 chromepath
 firefoxpath
4)Execute the testngSmoke file to execute all 3 smoke tests in single run.
***Note***: In order to generate ReportNg reports, disable default Listeners of testNG.
The report can be opened from test-output->html->index.html

**How to use**:
-The page classes have a basePage class having all the common mehtods. All the page classes will inherit this basePage to avoid redefining methods. 
-All the wait methods, wait and click and wait and sendKeys methods are defined here. The page classes will use page Object pattern. Methods are also defined within the pages in oreder to call the elements for the specified action to be performed on them.
-The test class has four packages namely:
 [Package 1]:  (com.wal.test) : this package has the tests defined inside in 3 different classes divided as per their functionalities.
                    (LandingPageTests)  : should include all the test methods for the landing page of application
                    (AisleTest)         : should include all the test methods for the aisles dropdown of application
                    (CartTest)          : should include all the test methods fo the cart in the application

 [Package 2]:  (com.wal.utility) : this is a utility storage class having all the upporting classes.
                    (HelperClass)       : Includes the @Before and @After method which is common to all the test cases and is nherited y                                           all the test classes. Webdriver is instantiated from the Helper class
                    (TestUtil)          : This class has not been used in the project but has been added for additional utilty to drive                                           data from the excel sheet
                    (Xls_Reader)        : This class has not been used in the project but has been added for additional utilty to drive                                           data from the excel sheet. It has all the methods to extract data from an excel sheet which                                             can be used for muliple set of data, if each scenario has to be executed with multiple data.In                                           this case @dataprovider annotation will be used in the test method. 
    
  [Package 3]:  (TestNG)  : this package contains the Testng Xml file that drives the test. The tests can be run individually or can be                             grouped, sequenced or mapped as per test requirements.
                     (testngSmoke)       : Drives the test by grouping all the 3 smoke tests together and passing parameters to the                                                required test cases.
                     
  [Pacakge 4]:   (Listeners) : this package has not been used as the reporting method used is ReportNG. The interface class defined                                    under this package extends the testListeners provided by TestNG for logging purposes. Can be used for                                    adding loggers into testNG reports or extent reports. I wanted to use Extent Reports for this project,                                  but was getting a blank report after execution everytime. Still trying to debug the problem and it seems                                to be a version update problem.  
  
