package com.wal.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProductPage extends BasePage {

	/*
	 * Page Object Pattern used for defining the elements in the web page. Each page
	 * class is inheriting BasePage
	 */
	private By buttonBakeryAndDessert = By.linkText("Frozen Bakery & Dessert");
	private By buttonAddToCart = By.xpath("(//*[@class='button add-to-cart-btn limited-stock'])[1]");
	private By numberOnCart = By.xpath("//*[@class='cart-count']");

	public ProductPage(WebDriver driver) {
		super(driver);
	}

	/*
	 * Methods that use the page objects have defined below, that will be called in
	 * the test classes
	 */
	public void clickBakeryAndDessert() throws Throwable {
		getElementAndClick(buttonBakeryAndDessert);
//		Reporter.log("Clicked on Bakery And Dessert", true);

	}

	public void ClickAddToCart() throws Throwable {
		getElementAndClick(buttonAddToCart);
//		Reporter.log("Clicked on Add to Cart for the first item on Bakery and Desserts", true);
	}

	public boolean verifyCartUpdate() throws Throwable {
		waitForElementToAppear(numberOnCart);
		String number = driver.findElement(numberOnCart).getText();
		if (number.equals("1")) {
//			Reporter.log("Cart has been correctly updated by 1", true);
		}
		return true;
	}

}
