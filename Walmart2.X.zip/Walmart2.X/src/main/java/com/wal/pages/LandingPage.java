package com.wal.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class LandingPage extends BasePage {

	/*
	 * Page Object Pattern used for defining the elements in the web page. Each page
	 * class is inheriting BasePage
	 */

	private By SearchBox = By.xpath("//*[@id='global-search']");
	private By buttonSearch = By.xpath("//*[@id='simplified-header']/div[2]/div/div[4]/form/button");
	private By buttonCart = By.xpath("//*[@id='nav-cart-mobile']/span");
	private By verifymainSlot = By.xpath("(//*[@id='tab-slot-main3-tab1-tabpanel'])[1]");
	private By Aisles = By.xpath("//*[@id='simplified-header']/div[2]/div/div[2]/nav/button/p/span[2]");
	private By linkFrozenFood = By.linkText("Frozen Food");
	private By titleBar = By.xpath("//*[@id='banana-template']/div[4]/h1");

	public LandingPage(WebDriver driver) {
		super(driver);
	}

	/*
	 * Methods that use the page objects have defined below, that will be called in
	 * the test classes
	 */
	public void EnterSearchAndClick(String product) throws Throwable {
		getElementAndEnter(SearchBox, product);
//		Reporter.log("Entered the Search Product as: " + product, true);
		getElementAndClick(buttonSearch);
//		Reporter.log("Clicked on search button", true);
	}

	public void ClickOnCart() throws Throwable {
		getElementAndClick(buttonCart);
	}

	public void HoverOverAisles() throws Throwable {
		Actions action = new Actions(driver);
		WebElement element = driver.findElement(Aisles);
		action.moveToElement(element).perform();
//		Reporter.log("Sucessful hover over on aisle", true);
	}

	public void ClickAisleProductFrozenFood() throws Throwable {
		getElementAndClick(linkFrozenFood);
//		Reporter.log("Clicked on Frozen Food link under Aisles", true);
	}

	public boolean verifyPageFrozenFood() throws Throwable {
		waitForElementToAppear(titleBar);
		String text = driver.findElement(titleBar).getText();
		if (text.contains("Frozen Food")) {
//			Reporter.log("Frozen Food product page open", true);
		}
		return true;

	}

	public void verifySearchResultPage() throws Throwable {
		waitForElementToDisappear(verifymainSlot);
//		Reporter.log("The main slot disappeared, the search product page is open", true);

	}
	public void verifyAlertPresence() {
		isAlertPresent();
	}
}
