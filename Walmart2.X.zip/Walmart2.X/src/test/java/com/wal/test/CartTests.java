package com.wal.test;

import org.testng.Assert;
import org.testng.annotations.Test;
import com.wal.pages.LandingPage;
import com.wal.pages.ProductPage;
import com.wal.utility.HelperClass;

/*
 *This test class will define all the test methods for testing the cart functionality on web page
 * 
 */
public class CartTests extends HelperClass {

	/* SmokeTest03
	 * Cart Update Functionality: On buying a product, the cart is updated.
	 * Following method will be validating one product purchase
	 */
	@Test(groups = { "smoke" })
	public void cartUpdateTest() throws Throwable {

		try {
			LandingPage lp = new LandingPage(getDriver());
			ProductPage pp = new ProductPage(getDriver());
			lp.HoverOverAisles();
			lp.ClickAisleProductFrozenFood();
			lp.verifyPageFrozenFood();
			pp.clickBakeryAndDessert();
			pp.ClickAddToCart();
			pp.verifyCartUpdate();
			lp.verifyAlertPresence();
		} catch (Exception e) {
			Assert.fail(e.toString());

		}
	}

}
