package com.wal.test;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.wal.pages.LandingPage;
import com.wal.utility.HelperClass;

/*
 * This class will have all the test cases to test the functionality of 'Aisle' on the web page
 */

public class AisleTests extends HelperClass {
	
	/*
	 * Product click functionality: Clicking on any product within the aisles drop down opens the product page.
	 * Have defined only Frozen Food category here for the assignment and categorized it as 'smoke'
	 */
	
	@Test(groups= {"smoke"})
	public void aisleFrozenFoodTest() throws Throwable {

		try {
			LandingPage lp = new LandingPage(getDriver());
			lp.HoverOverAisles();
			lp.ClickAisleProductFrozenFood();
			lp.verifyPageFrozenFood();
			lp.verifyAlertPresence();
		} catch (Exception e) {
			Assert.fail(e.toString());

		}
	}
}
