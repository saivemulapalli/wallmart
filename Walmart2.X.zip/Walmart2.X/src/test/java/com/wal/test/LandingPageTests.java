package com.wal.test;

import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.wal.pages.LandingPage;
import com.wal.utility.HelperClass;

/*
 * This test class will define all the test methods to test the Landing page functionalities.
 */

public class LandingPageTests extends HelperClass {

	/*SmokeTest01:
	 * Description: Search box functionality: A user is able to enter 
	 his/her search product in the search box and able to proceed to product page
	 */
	@Test(groups = { "smoke" })
	@Parameters({ "SearchProduct" })
	public void searchBoxTest(String SearchProduct) throws Throwable {

		try {
			LandingPage lp = new LandingPage(getDriver());
			lp.EnterSearchAndClick(SearchProduct);
			lp.verifySearchResultPage();
		} catch (Exception e) {
			Assert.fail(e.toString());

		}

	}

}
