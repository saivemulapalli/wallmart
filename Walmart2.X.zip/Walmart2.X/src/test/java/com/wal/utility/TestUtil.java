package com.wal.utility;

import java.util.ArrayList;

/*
 * Please ignore this class for now.
 * can be used in order to execute the same test case with multiple data by reading the data from excel sheet and 
 * storing  in Arraylist. This list can be called in methods using @dataProvider annotation
 * 
 */
public class TestUtil {
	static Xls_Reader reader;

	public static ArrayList<Object[]> getExcelData() {

		ArrayList<Object[]> walData = new ArrayList<Object[]>();

		try {
			reader = new Xls_Reader(System.getProperty("---file path---"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		for (int rowNum = 2; rowNum <= reader.getRowCount("data"); rowNum++) {
			String product = reader.getCellData("sheetName", "colNum", rowNum);

			walData.add(new Object[] { product });
		}
		return walData;
	}

}
