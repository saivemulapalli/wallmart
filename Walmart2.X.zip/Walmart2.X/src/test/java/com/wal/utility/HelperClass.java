package com.wal.utility;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;


/*
 * The Helper class has the common methods for all test classes
 * 
 */
public class HelperClass {

	private WebDriver driver;
//	static ExtentTest test;
//	static ExtentReports report;

	
	/*
	 * The following method will be called before any class execution starts and will initiate the bowser
	 */
	@BeforeClass(alwaysRun = true)
	@Parameters({ "browser", "chromePath", "firefoxPath", "url" })
	public void setup(String browser, String chromePath, String firefoxPath, String url) {

//		String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
//		report = new ExtentReports(System.getProperty("user.dir")+"\\ExtentReportResults"+ timeStamp +".html",true);

		if (browser.equals("chrome")) {
			System.setProperty("webdriver.chrome.driver", chromePath);
			driver = new ChromeDriver();
		} else if (browser.equals("firefox")) {
			System.setProperty("webdriver.firefox.driver", firefoxPath);
			driver = new FirefoxDriver();
		}
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		driver.get(url);
		Reporter.log("=====Application Started=====", true);
		Reporter.log("Entered url: " + url, true);
	}

	/*
	 * The following method will be called after any class execution stops and will close the browser
	 */
	@AfterClass(alwaysRun = true)
	public void tearDown() {
		driver.quit();
		Reporter.log("=====Browser Session End=====", true);
	}

	/*
	 * Constructor method to instantiate the driver in all dependent test classes
	 */
	public WebDriver getDriver() {
		return driver;
	}


}
